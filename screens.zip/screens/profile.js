import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  TextInput,
  FlatList,
  ScrollView
} from "react-native";
import * as firebase from "firebase";

export default class profile extends React.Component {
  render() {
    return (
      <ScrollView>
        <View
          style={{
            backgroundColor: "white",
            flex: 1
          }}
        >
          <View style={{ flexDirection: "row", margin: 30 }}>
            <Image
              style={{ width: 90, height: 90 }}
              source={require("../assets/logo.jpg")}
            />
            <Text style={{ fontSize: 40 }}>First Aid Kit</Text>
          </View>

          <View style={{ flexDirection: "row", margin: 20 }}>
            <Image
              style={{ width: 50, height: 50 }}
              source={require("../assets/ampu.png")}
            />

            <Text style={{ fontSize: 15 }}>Call the ambulance 101</Text>
          </View>
          <View style={{ flexDirection: "row", margin: 20 }}>
            <Image
              style={{ width: 50, height: 50 }}
              source={require("../assets/civil.png")}
            />
            <Text style={{ fontSize: 15 }}>Call the Civil Defense 102</Text>
          </View>
          <View
            style={{
              alignItems: "center",
              justifyContent: "center",
              margin: 20
            }}
          >
            <Text
              style={{
                fontSize: 25,
                borderWidth: 3,
                borderColor: "red"
              }}
            >
              We can help you!
            </Text>
          </View>
          <View style={{ flexDirection: "row", margin: 1 }}>
            <Text style={{ fontSize: 20 }}>
              A first aid kit is a collection of supplies{"\n"} and equipment
              that is used to give{"\n"} medical treatment.
            </Text>
          </View>
        </View>
      </ScrollView>
    );
  }
}
